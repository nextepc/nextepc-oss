var searchData=
[
  ['welcome_20to_20the_20documentation_20site_20for_20prometheus_2dclient_2dc_21',['Welcome to the documentation site for prometheus-client-c!',['../index.html',1,'']]]
];
